@echo off
rem Abre VetCompras con los datos guardados en esta misma USB (carpeta "datos").
start "" wscript.exe "%~dp0VetCompras.vbs" /usb
