' Abre VetCompras sin ventana negra. Si ya está abierto, solo abre el navegador.
' Uso: VetCompras.vbs            -> datos en C:\Users\<usuario>\VetCompras\datos
'      VetCompras.vbs /usb       -> datos en la carpeta "datos" junto a este archivo
Option Explicit
Dim shell, fso, carpeta, puerto, url, i, enUsb, entorno, abrirNavegador, a

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
carpeta = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = carpeta
enUsb = False
abrirNavegador = True
For Each a In WScript.Arguments
  If LCase(a) = "/usb" Then enUsb = True
  If LCase(a) = "/sinnavegador" Then abrirNavegador = False
Next

puerto = LeerPuerto()
url = "http://localhost:" & puerto

If Not EstaFuncionando() Then
  Set entorno = shell.Environment("Process")
  entorno("VETCOMPRAS_LOG") = carpeta & "\registro.log"
  If enUsb Then
    If fso.FileExists(carpeta & "\ETAPA_PRUEBA") Then
      entorno("VETCOMPRAS_DATOS") = carpeta & "\datos-prueba"
    Else
      entorno("VETCOMPRAS_DATOS") = carpeta & "\datos"
    End If
  End If
  shell.Run """" & carpeta & "\node\node.exe"" """ & carpeta & "\servidor.mjs""", 0, False
  For i = 1 To 60
    WScript.Sleep 500
    If EstaFuncionando() Then Exit For
  Next
  If Not EstaFuncionando() Then
    MsgBox "VetCompras no pudo iniciar." & vbCrLf & "Revise el archivo registro.log en " & carpeta, vbCritical, "VetCompras"
    WScript.Quit 1
  End If
End If
If abrirNavegador Then shell.Run url

Function EstaFuncionando()
  Dim http
  EstaFuncionando = False
  On Error Resume Next
  Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  http.setTimeouts 1000, 1000, 1000, 1000
  http.Open "GET", url & "/api/sesion", False
  http.Send
  If Err.Number = 0 Then
    If http.Status = 200 Then EstaFuncionando = True
  End If
  On Error GoTo 0
End Function

Function LeerPuerto()
  Dim archivo, linea
  LeerPuerto = "3000"
  If fso.FileExists(carpeta & "\.env") Then
    Set archivo = fso.OpenTextFile(carpeta & "\.env", 1)
    Do Until archivo.AtEndOfStream
      linea = Trim(archivo.ReadLine)
      If LCase(Left(linea, 7)) = "puerto=" Then LeerPuerto = Trim(Mid(linea, 8))
    Loop
    archivo.Close
  End If
End Function
