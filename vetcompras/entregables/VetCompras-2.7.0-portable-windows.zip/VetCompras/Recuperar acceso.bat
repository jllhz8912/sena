@echo off
chcp 65001 >nul
echo Crea un acceso de emergencia de administrador (si olvidó la contraseña).
echo Si usa VetCompras desde la USB, escriba U; si está instalado en este PC, escriba P.
set /p MODO="(U/P): "
if /i "%MODO%"=="U" set VETCOMPRAS_DATOS=%~dp0datos
"%~dp0node\node.exe" "%~dp0recuperar.mjs"
pause
