@echo off
chcp 65001 >nul
echo ============================================================
echo   DEJAR LIMPIO PARA ENTREGAR
echo ============================================================
echo Borra los datos guardados DENTRO de esta carpeta (modo USB),
echo la licencia de este equipo y el registro, para entregar el
echo programa nuevo, sin datos ni historial.
echo.
echo NO toca los datos del PC en %USERPROFILE%\SistemaControl.
echo.
choice /C SN /M "¿Desea continuar? S = si, N = no"
if errorlevel 2 exit /b
taskkill /fi "WINDOWTITLE eq Sistema de Control - servidor*" /t /f >nul 2>nul
if exist "%~dp0datos" rmdir /s /q "%~dp0datos"
if exist "%~dp0datos-prueba" rmdir /s /q "%~dp0datos-prueba"
if exist "%~dp0registro.log" del /q "%~dp0registro.log"
echo.
echo Listo: la carpeta quedo limpia para entregar.
pause
