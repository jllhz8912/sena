@echo off
rem Abre Sistema de Control con los datos guardados en esta misma USB (carpeta "datos").
call "%~dp0Abrir Sistema de Control.cmd" /usb
