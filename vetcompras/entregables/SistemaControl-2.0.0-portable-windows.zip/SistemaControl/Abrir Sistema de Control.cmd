@echo off
rem Abre Sistema de Control. Si ya esta abierto, solo abre el navegador.
rem   Abrir Sistema de Control.cmd         datos en %USERPROFILE%\SistemaControl\datos
rem   Abrir Sistema de Control.cmd /usb    datos en la carpeta "datos" junto a este archivo
if not "%SC_MINIMIZADO%"=="1" (
  set SC_MINIMIZADO=1
  start "Sistema de Control - servidor" /min cmd /c ""%~f0" %*"
  exit /b
)
cd /d "%~dp0"
set ABRIR_NAVEGADOR=1
set VETCOMPRAS_LOG=%~dp0registro.log
if /i "%~1"=="/usb" (
  if exist "%~dp0ETAPA_PRUEBA" (set "SISTEMA_CONTROL_DATOS=%~dp0datos-prueba") else (set "SISTEMA_CONTROL_DATOS=%~dp0datos")
)
echo ============================================================
echo   SISTEMA DE CONTROL 2.0 esta funcionando.
echo   Deje esta ventana minimizada mientras usa el programa.
echo   Al cerrarla, el programa se detiene.
echo ============================================================
"%~dp0node\node.exe" "%~dp0servidor.mjs"
if errorlevel 1 (
  echo.
  echo No fue posible iniciar. Revise el archivo registro.log de esta carpeta.
  pause
)
