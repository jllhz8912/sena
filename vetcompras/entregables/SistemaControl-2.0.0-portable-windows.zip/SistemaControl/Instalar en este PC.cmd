@echo off
chcp 65001 >nul
title Instalar Sistema de Control 2.0 en este PC
set "ORIGEN=%~dp0"
set "DESTINO=%LOCALAPPDATA%\SistemaControl\programa"

echo ============================================================
echo   INSTALAR SISTEMA DE CONTROL 2.0 EN ESTE PC
echo   Programa: %DESTINO%
if exist "%ORIGEN%ETAPA_PRUEBA" (
  echo   VERSION DE PRUEBA - datos de ensayo en: %USERPROFILE%\SistemaControl\datos-prueba
) else (
  echo   Datos:    %USERPROFILE%\SistemaControl\datos
)
echo   Al abrirlo por primera vez se pide la LICENCIA de este equipo.
echo   Si ya estaba instalado, se actualiza y los datos se conservan.
echo ============================================================
pause

rem Cerrar el programa si esta abierto (para poder reemplazar archivos)
taskkill /fi "WINDOWTITLE eq Sistema de Control - servidor*" /t /f >nul 2>nul

if exist "%DESTINO%\ETAPA_PRUEBA" del /q "%DESTINO%\ETAPA_PRUEBA"
robocopy "%ORIGEN%." "%DESTINO%" /E /NFL /NDL /NJH /NJS /XD datos datos-prueba /XF registro.log "Usar desde la USB.cmd" "Instalar en este PC.cmd" >nul
rem Lanzadores de versiones anteriores
if exist "%DESTINO%\SistemaControl.vbs" del /q "%DESTINO%\SistemaControl.vbs"
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Sistema de Control.lnk" del /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Sistema de Control.lnk"

rem Acceso en el escritorio (un .cmd que llama al programa instalado)
set "ESCRITORIO=%USERPROFILE%\Desktop"
for /f "tokens=2,*" %%a in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v Desktop 2^>nul ^| find "REG_"') do call set "ESCRITORIO=%%b"
if exist "%ESCRITORIO%\Sistema de Control.lnk" del /q "%ESCRITORIO%\Sistema de Control.lnk"
(
  echo @echo off
  echo call "%DESTINO%\Abrir Sistema de Control.cmd"
) > "%ESCRITORIO%\Sistema de Control.cmd"

if exist "%ORIGEN%datos\vetcompras.db" (
  echo.
  echo Esta USB tiene datos propios en la carpeta "datos".
  echo Para pasarlos a este PC: en Copias de Seguridad de la USB use "Copiar y descargar"
  echo y luego "Cargar una copia de seguridad" en la version instalada.
)

echo.
echo LISTO. Abra "Sistema de Control" desde el escritorio.
pause
