import { createRequire as __vcRequire } from 'node:module'; const require = __vcRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/dotenv/lib/main.js
var require_main = __commonJS({
  "node_modules/dotenv/lib/main.js"(exports, module) {
    var fs2 = __require("fs");
    var path3 = __require("path");
    var os2 = __require("os");
    var crypto3 = __require("crypto");
    var TIPS = [
      "\u25C8 encrypted .env [www.dotenvx.com]",
      "\u25C8 secrets for agents [www.dotenvx.com]",
      "\u2301 auth for agents [www.vestauth.com]",
      "\u2318 custom filepath { path: '/custom/path/.env' }",
      "\u2318 enable debugging { debug: true }",
      "\u2318 override existing { override: true }",
      "\u2318 suppress logs { quiet: true }",
      "\u2318 multiple files { path: ['.env.local', '.env'] }"
    ];
    function _getRandomTip() {
      return TIPS[Math.floor(Math.random() * TIPS.length)];
    }
    function parseBoolean(value) {
      if (typeof value === "string") {
        return !["false", "0", "no", "off", ""].includes(value.toLowerCase());
      }
      return Boolean(value);
    }
    function supportsAnsi() {
      return process.stdout.isTTY;
    }
    function dim(text) {
      return supportsAnsi() ? `\x1B[2m${text}\x1B[0m` : text;
    }
    var LINE = /(?:^|^)\s*(?:export\s+)?([\w.-]+)(?:\s*=\s*?|:\s+?)(\s*'(?:\\'|[^'])*'|\s*"(?:\\"|[^"])*"|\s*`(?:\\`|[^`])*`|[^#\r\n]+)?\s*(?:#.*)?(?:$|$)/mg;
    function parse(src) {
      const obj = {};
      let lines = src.toString();
      lines = lines.replace(/\r\n?/mg, "\n");
      let match;
      while ((match = LINE.exec(lines)) != null) {
        const key = match[1];
        let value = match[2] || "";
        value = value.trim();
        const maybeQuote = value[0];
        value = value.replace(/^(['"`])([\s\S]*)\1$/mg, "$2");
        if (maybeQuote === '"') {
          value = value.replace(/\\n/g, "\n");
          value = value.replace(/\\r/g, "\r");
        }
        obj[key] = value;
      }
      return obj;
    }
    function _parseVault(options) {
      options = options || {};
      const vaultPath = _vaultPath(options);
      options.path = vaultPath;
      const result = DotenvModule.configDotenv(options);
      if (!result.parsed) {
        const err = new Error(`MISSING_DATA: Cannot parse ${vaultPath} for an unknown reason`);
        err.code = "MISSING_DATA";
        throw err;
      }
      const keys = _dotenvKey(options).split(",");
      const length = keys.length;
      let decrypted;
      for (let i = 0; i < length; i++) {
        try {
          const key = keys[i].trim();
          const attrs = _instructions(result, key);
          decrypted = DotenvModule.decrypt(attrs.ciphertext, attrs.key);
          break;
        } catch (error2) {
          if (i + 1 >= length) {
            throw error2;
          }
        }
      }
      return DotenvModule.parse(decrypted);
    }
    function _warn(message) {
      console.error(`\u26A0 ${message}`);
    }
    function _debug(message) {
      console.log(`\u2506 ${message}`);
    }
    function _log(message) {
      console.log(`\u25C7 ${message}`);
    }
    function _dotenvKey(options) {
      if (options && options.DOTENV_KEY && options.DOTENV_KEY.length > 0) {
        return options.DOTENV_KEY;
      }
      if (process.env.DOTENV_KEY && process.env.DOTENV_KEY.length > 0) {
        return process.env.DOTENV_KEY;
      }
      return "";
    }
    function _instructions(result, dotenvKey) {
      let uri;
      try {
        uri = new URL(dotenvKey);
      } catch (error2) {
        if (error2.code === "ERR_INVALID_URL") {
          const err = new Error("INVALID_DOTENV_KEY: Wrong format. Must be in valid uri format like dotenv://:key_1234@dotenvx.com/vault/.env.vault?environment=development");
          err.code = "INVALID_DOTENV_KEY";
          throw err;
        }
        throw error2;
      }
      const key = uri.password;
      if (!key) {
        const err = new Error("INVALID_DOTENV_KEY: Missing key part");
        err.code = "INVALID_DOTENV_KEY";
        throw err;
      }
      const environment = uri.searchParams.get("environment");
      if (!environment) {
        const err = new Error("INVALID_DOTENV_KEY: Missing environment part");
        err.code = "INVALID_DOTENV_KEY";
        throw err;
      }
      const environmentKey = `DOTENV_VAULT_${environment.toUpperCase()}`;
      const ciphertext = result.parsed[environmentKey];
      if (!ciphertext) {
        const err = new Error(`NOT_FOUND_DOTENV_ENVIRONMENT: Cannot locate environment ${environmentKey} in your .env.vault file.`);
        err.code = "NOT_FOUND_DOTENV_ENVIRONMENT";
        throw err;
      }
      return { ciphertext, key };
    }
    function _vaultPath(options) {
      let possibleVaultPath = null;
      if (options && options.path && options.path.length > 0) {
        if (Array.isArray(options.path)) {
          for (const filepath of options.path) {
            if (fs2.existsSync(filepath)) {
              possibleVaultPath = filepath.endsWith(".vault") ? filepath : `${filepath}.vault`;
            }
          }
        } else {
          possibleVaultPath = options.path.endsWith(".vault") ? options.path : `${options.path}.vault`;
        }
      } else {
        possibleVaultPath = path3.resolve(process.cwd(), ".env.vault");
      }
      if (fs2.existsSync(possibleVaultPath)) {
        return possibleVaultPath;
      }
      return null;
    }
    function _resolveHome(envPath) {
      return envPath[0] === "~" ? path3.join(os2.homedir(), envPath.slice(1)) : envPath;
    }
    function _configVault(options) {
      const debug = parseBoolean(process.env.DOTENV_CONFIG_DEBUG || options && options.debug);
      const quiet = parseBoolean(process.env.DOTENV_CONFIG_QUIET || options && options.quiet);
      if (debug || !quiet) {
        _log("loading env from encrypted .env.vault");
      }
      const parsed = DotenvModule._parseVault(options);
      let processEnv = process.env;
      if (options && options.processEnv != null) {
        processEnv = options.processEnv;
      }
      DotenvModule.populate(processEnv, parsed, options);
      return { parsed };
    }
    function configDotenv(options) {
      const dotenvPath = path3.resolve(process.cwd(), ".env");
      let encoding = "utf8";
      let processEnv = process.env;
      if (options && options.processEnv != null) {
        processEnv = options.processEnv;
      }
      let debug = parseBoolean(processEnv.DOTENV_CONFIG_DEBUG || options && options.debug);
      let quiet = parseBoolean(processEnv.DOTENV_CONFIG_QUIET || options && options.quiet);
      if (options && options.encoding) {
        encoding = options.encoding;
      } else {
        if (debug) {
          _debug("no encoding is specified (UTF-8 is used by default)");
        }
      }
      let optionPaths = [dotenvPath];
      if (options && options.path) {
        if (!Array.isArray(options.path)) {
          optionPaths = [_resolveHome(options.path)];
        } else {
          optionPaths = [];
          for (const filepath of options.path) {
            optionPaths.push(_resolveHome(filepath));
          }
        }
      }
      let lastError;
      const parsedAll = {};
      for (const path4 of optionPaths) {
        try {
          const parsed = DotenvModule.parse(fs2.readFileSync(path4, { encoding }));
          DotenvModule.populate(parsedAll, parsed, options);
        } catch (e) {
          if (debug) {
            _debug(`failed to load ${path4} ${e.message}`);
          }
          lastError = e;
        }
      }
      const populated = DotenvModule.populate(processEnv, parsedAll, options);
      debug = parseBoolean(processEnv.DOTENV_CONFIG_DEBUG || debug);
      quiet = parseBoolean(processEnv.DOTENV_CONFIG_QUIET || quiet);
      if (debug || !quiet) {
        const keysCount = Object.keys(populated).length;
        const shortPaths = [];
        for (const filePath of optionPaths) {
          try {
            const relative = path3.relative(process.cwd(), filePath);
            shortPaths.push(relative);
          } catch (e) {
            if (debug) {
              _debug(`failed to load ${filePath} ${e.message}`);
            }
            lastError = e;
          }
        }
        _log(`injected env (${keysCount}) from ${shortPaths.join(",")} ${dim(`// tip: ${_getRandomTip()}`)}`);
      }
      if (lastError) {
        return { parsed: parsedAll, error: lastError };
      } else {
        return { parsed: parsedAll };
      }
    }
    function config(options) {
      if (_dotenvKey(options).length === 0) {
        return DotenvModule.configDotenv(options);
      }
      const vaultPath = _vaultPath(options);
      if (!vaultPath) {
        _warn(`you set DOTENV_KEY but you are missing a .env.vault file at ${vaultPath}`);
        return DotenvModule.configDotenv(options);
      }
      return DotenvModule._configVault(options);
    }
    function decrypt(encrypted, keyStr) {
      const key = Buffer.from(keyStr.slice(-64), "hex");
      let ciphertext = Buffer.from(encrypted, "base64");
      const nonce = ciphertext.subarray(0, 12);
      const authTag = ciphertext.subarray(-16);
      ciphertext = ciphertext.subarray(12, -16);
      try {
        const aesgcm = crypto3.createDecipheriv("aes-256-gcm", key, nonce);
        aesgcm.setAuthTag(authTag);
        return `${aesgcm.update(ciphertext)}${aesgcm.final()}`;
      } catch (error2) {
        const isRange = error2 instanceof RangeError;
        const invalidKeyLength = error2.message === "Invalid key length";
        const decryptionFailed = error2.message === "Unsupported state or unable to authenticate data";
        if (isRange || invalidKeyLength) {
          const err = new Error("INVALID_DOTENV_KEY: It must be 64 characters long (or more)");
          err.code = "INVALID_DOTENV_KEY";
          throw err;
        } else if (decryptionFailed) {
          const err = new Error("DECRYPTION_FAILED: Please check your DOTENV_KEY");
          err.code = "DECRYPTION_FAILED";
          throw err;
        } else {
          throw error2;
        }
      }
    }
    function populate(processEnv, parsed, options = {}) {
      const debug = Boolean(options && options.debug);
      const override = Boolean(options && options.override);
      const populated = {};
      if (typeof parsed !== "object") {
        const err = new Error("OBJECT_REQUIRED: Please check the processEnv argument being passed to populate");
        err.code = "OBJECT_REQUIRED";
        throw err;
      }
      for (const key of Object.keys(parsed)) {
        if (Object.prototype.hasOwnProperty.call(processEnv, key)) {
          if (override === true) {
            processEnv[key] = parsed[key];
            populated[key] = parsed[key];
          }
          if (debug) {
            if (override === true) {
              _debug(`"${key}" is already defined and WAS overwritten`);
            } else {
              _debug(`"${key}" is already defined and was NOT overwritten`);
            }
          }
        } else {
          processEnv[key] = parsed[key];
          populated[key] = parsed[key];
        }
      }
      return populated;
    }
    var DotenvModule = {
      configDotenv,
      _configVault,
      _parseVault,
      config,
      decrypt,
      parse,
      populate
    };
    module.exports.configDotenv = DotenvModule.configDotenv;
    module.exports._configVault = DotenvModule._configVault;
    module.exports._parseVault = DotenvModule._parseVault;
    module.exports.config = DotenvModule.config;
    module.exports.decrypt = DotenvModule.decrypt;
    module.exports.parse = DotenvModule.parse;
    module.exports.populate = DotenvModule.populate;
    module.exports = DotenvModule;
  }
});

// server/silenciarAvisos.ts
var emitirAviso = process.emitWarning.bind(process);
process.emitWarning = ((aviso, ...resto) => {
  if (String(aviso).includes("SQLite")) return;
  return emitirAviso(aviso, ...resto);
});

// scripts/recuperarAcceso.ts
var import_dotenv = __toESM(require_main(), 1);
import crypto2 from "node:crypto";
import path2 from "node:path";
import { fileURLToPath } from "node:url";

// server/basedatos.ts
import { createRequire } from "node:module";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

// src/utils/formatters.ts
var CATEGORIAS_VENTA = [
  { id: "consultas_clinica", label: "Consultas cl\xEDnica" },
  { id: "tratamientos_clinica", label: "Tratamientos cl\xEDnica" },
  { id: "vacunas", label: "Vacunas" },
  { id: "banos", label: "Ba\xF1os y peluquer\xEDa" },
  { id: "purinas_empaque", label: "Purinas (bultos y paquetes)" },
  { id: "purinas_granel", label: "Purinas a granel" },
  { id: "vitrina", label: "Vitrina" },
  { id: "varios", label: "Varios / Otros" }
];
var SUBCATEGORIAS_BANOS = [
  { value: "bano_estetico", label: "1. Ba\xF1o est\xE9tico", nombreCorto: "Ba\xF1o Est\xE9tico", badgeColor: "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800" },
  { value: "bano_medicado", label: "2. Ba\xF1o medicado", nombreCorto: "Ba\xF1o Medicado", badgeColor: "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800" },
  { value: "bano_antipulgas", label: "3. Ba\xF1o antipulgas", nombreCorto: "Ba\xF1o Antipulgas", badgeColor: "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800" },
  { value: "peluqueria_corte", label: "4. Peluquer\xEDa / Corte", nombreCorto: "Peluquer\xEDa", badgeColor: "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800" },
  { value: "varios", label: "5. Varios (corte u\xF1as, limpieza o\xEDdos, otros)", nombreCorto: "Varios", badgeColor: "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" }
];
var SUBCATEGORIAS_VACUNAS = [
  { value: "antirrabica", label: "1. Antirr\xE1bica", nombreCorto: "Antirr\xE1bica", badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800" },
  { value: "sextuple", label: "2. S\xE9xtuple / M\xFAltiple", nombreCorto: "S\xE9xtuple", badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800" },
  { value: "triple_felina", label: "3. Triple Felina", nombreCorto: "Triple Felina", badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800" },
  { value: "parvovirus", label: "4. Parvovirus / Corona", nombreCorto: "Parvo/Corona", badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800" },
  { value: "tos_perreras", label: "5. Tos de Perreras (KC)", nombreCorto: "Tos Perreras", badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800" },
  { value: "varios", label: "6. Varios (otras vacunas o refuerzos)", nombreCorto: "Varios", badgeColor: "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" }
];
var SUBCATEGORIAS_CONSULTAS = [
  { value: "consulta_general", label: "1. Consulta general", nombreCorto: "Consulta General", badgeColor: "bg-sky-100 text-sky-800 border-sky-200 dark:bg-sky-950/60 dark:text-sky-300 dark:border-sky-800" },
  { value: "consulta_urgencias", label: "2. Consulta de urgencias", nombreCorto: "Consulta Urgencias", badgeColor: "bg-sky-100 text-sky-800 border-sky-200 dark:bg-sky-950/60 dark:text-sky-300 dark:border-sky-800" },
  { value: "control_medico", label: "3. Control m\xE9dico / Revisi\xF3n", nombreCorto: "Control M\xE9dico", badgeColor: "bg-sky-100 text-sky-800 border-sky-200 dark:bg-sky-950/60 dark:text-sky-300 dark:border-sky-800" },
  { value: "certificado_viaje", label: "4. Certificado salud / viaje", nombreCorto: "Certificado Viaje", badgeColor: "bg-sky-100 text-sky-800 border-sky-200 dark:bg-sky-950/60 dark:text-sky-300 dark:border-sky-800" },
  { value: "varios", label: "5. Varios (otras consultas o valoraciones)", nombreCorto: "Varios", badgeColor: "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" }
];
var SUBCATEGORIAS_TRATAMIENTOS = [
  { value: "parvovirus", label: "1. Parvovirus", nombreCorto: "Parvovirus", badgeColor: "bg-rose-100 text-rose-800 border-rose-200 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800" },
  { value: "triaditis", label: "2. Triaditis felina o canina", nombreCorto: "Triaditis", badgeColor: "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800" },
  { value: "sintomatologia", label: "3. Sintomatolog\xEDa", nombreCorto: "Sintomatolog\xEDa", badgeColor: "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800" },
  { value: "moquillo", label: "4. Moquillo", nombreCorto: "Moquillo", badgeColor: "bg-red-100 text-red-800 border-red-200 dark:bg-red-950/60 dark:text-red-300 dark:border-red-800" },
  { value: "gastroenteritis", label: "5. Gastroenteritis", nombreCorto: "Gastroenteritis", badgeColor: "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-950/60 dark:text-orange-300 dark:border-orange-800" },
  { value: "cirugias", label: "6. Cirug\xEDas", nombreCorto: "Cirug\xEDas", badgeColor: "bg-indigo-100 text-indigo-800 border-indigo-200 dark:bg-indigo-950/60 dark:text-indigo-300 dark:border-indigo-800" },
  { value: "varios", label: "7. Varios (otros tratamientos)", nombreCorto: "Varios", badgeColor: "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" }
];
var SUBCATEGORIAS_PURINAS_EMPAQUE = [
  { value: "bulto_perro", label: "1. Bulto perro adulto (15-30 kg)", nombreCorto: "Bulto Perro", badgeColor: "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800" },
  { value: "bulto_cachorro", label: "2. Bulto perro cachorro (15-30 kg)", nombreCorto: "Bulto Cachorro", badgeColor: "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800" },
  { value: "paquete_pequeno", label: "3. Paquete bolsa (1-8 kg)", nombreCorto: "Paquete Bolsa", badgeColor: "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800" },
  { value: "bulto_gato", label: "4. Bulto / Paquete gato", nombreCorto: "Purina Gato", badgeColor: "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800" },
  { value: "alimento_prescrito", label: "5. Alimento medicado / prescrito", nombreCorto: "Alimento Prescrito", badgeColor: "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800" },
  { value: "varios", label: "6. Varios (otras marcas o empaques)", nombreCorto: "Varios", badgeColor: "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" }
];
var SUBCATEGORIAS_PURINAS_GRANEL = [
  { value: "granel_adulto", label: "1. Purina perro adulto (Kg/Lb)", nombreCorto: "Granel Adulto", badgeColor: "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-950/60 dark:text-orange-300 dark:border-orange-800" },
  { value: "granel_cachorro", label: "2. Purina cachorro (Kg/Lb)", nombreCorto: "Granel Cachorro", badgeColor: "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-950/60 dark:text-orange-300 dark:border-orange-800" },
  { value: "granel_gato", label: "3. Purina felina (Kg/Lb)", nombreCorto: "Granel Gato", badgeColor: "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-950/60 dark:text-orange-300 dark:border-orange-800" },
  { value: "varios", label: "4. Varios (otra purina a granel)", nombreCorto: "Varios", badgeColor: "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" }
];
var SUBCATEGORIAS_VITRINA = [
  { value: "desparasitantes", label: "1. Desparasitantes", nombreCorto: "Desparasitantes", badgeColor: "bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800" },
  { value: "nexgard", label: "2. Nexgard", nombreCorto: "Nexgard", badgeColor: "bg-teal-100 text-teal-800 border-teal-200 dark:bg-teal-950/60 dark:text-teal-300 dark:border-teal-800" },
  { value: "gotas_pulgas", label: "3. Gotas pulgas", nombreCorto: "Gotas pulgas", badgeColor: "bg-cyan-100 text-cyan-800 border-cyan-200 dark:bg-cyan-950/60 dark:text-cyan-300 dark:border-cyan-800" },
  { value: "shampoo_lociones", label: "4. Shampoo, lociones", nombreCorto: "Shampoo / Lociones", badgeColor: "bg-sky-100 text-sky-800 border-sky-200 dark:bg-sky-950/60 dark:text-sky-300 dark:border-sky-800" },
  { value: "medicamentos", label: "5. Medicamentos", nombreCorto: "Medicamentos", badgeColor: "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800" },
  { value: "dulces", label: "6. Dulces (comida h\xFAmedas, galletas y dem\xE1s)", nombreCorto: "Dulces / Snacks", badgeColor: "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800" },
  { value: "cream_helado", label: "7. Cream helado (paletas, helados)", nombreCorto: "Cream Helado", badgeColor: "bg-pink-100 text-pink-800 border-pink-200 dark:bg-pink-950/60 dark:text-pink-300 dark:border-pink-800" },
  { value: "varios", label: "8. Varios (accesorios, collares, juguetes, otros)", nombreCorto: "Varios", badgeColor: "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" }
];
var SUBCATEGORIAS_VARIOS = [
  { value: "guarderia", label: "1. Guarder\xEDa / Hospedaje", nombreCorto: "Guarder\xEDa", badgeColor: "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" },
  { value: "transporte", label: "2. Transporte / Domicilio", nombreCorto: "Transporte", badgeColor: "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" },
  { value: "laboratorio_externo", label: "3. Ex\xE1menes / Laboratorio externo", nombreCorto: "Laboratorio", badgeColor: "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" },
  { value: "varios", label: "4. Varios (concepto nuevo libre)", nombreCorto: "Varios", badgeColor: "bg-slate-100 text-slate-800 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700" }
];
var SUBCATEGORIAS_POR_CATEGORIA = {
  banos: SUBCATEGORIAS_BANOS,
  vacunas: SUBCATEGORIAS_VACUNAS,
  consultas_clinica: SUBCATEGORIAS_CONSULTAS,
  clinica: SUBCATEGORIAS_CONSULTAS,
  tratamientos_clinica: SUBCATEGORIAS_TRATAMIENTOS,
  medicamentos: SUBCATEGORIAS_TRATAMIENTOS,
  purinas_empaque: SUBCATEGORIAS_PURINAS_EMPAQUE,
  purinas: SUBCATEGORIAS_PURINAS_EMPAQUE,
  purinas_granel: SUBCATEGORIAS_PURINAS_GRANEL,
  vitrina: SUBCATEGORIAS_VITRINA,
  pet_shop: SUBCATEGORIAS_VITRINA,
  varios: SUBCATEGORIAS_VARIOS
};
var CATEGORIAS_SERVICIO = /* @__PURE__ */ new Set(["consultas_clinica", "tratamientos_clinica", "vacunas", "banos"]);
var CATEGORIAS_VENTA_TODAS = CATEGORIAS_VENTA.map((c) => ({ ...c }));
var CATEGORIAS_BASE = CATEGORIAS_VENTA.map((c) => ({ ...c }));
var SERVICIO_BASE = new Set(CATEGORIAS_SERVICIO);
var SUBCATEGORIAS_BASE = { ...SUBCATEGORIAS_POR_CATEGORIA };

// src/data/defaults.ts
var EMPRESA_DEFECTO = {
  razonSocial: "MI EMPRESA S.A.S.",
  nombreComercial: "Mi Empresa",
  nit: "",
  dv: "",
  direccion: "",
  ciudad: "",
  departamento: "",
  telefono: "",
  whatsapp: "",
  email: "",
  matriculaMercantil: "",
  regimenTributario: "No Responsable de IVA",
  responsableIva: false,
  colorPrimario: "#2563eb",
  colorSecundario: "#0f766e",
  slogan: "",
  sitioWeb: "",
  tituloDocumentoVenta: "COMPROBANTE DE VENTA",
  textoPieRecibo: "\xA1Gracias por su compra! Conserve este comprobante.",
  resolucionLegal: "",
  etiquetaReferencia: "Referencia"
};
var SUBCATEGORIAS_COMPRA_DEFECTO = {
  "cat-mercancia": [
    { id: "mercancia_general", nombre: "Mercanc\xEDa general para reventa" },
    { id: "materias_primas", nombre: "Materias primas e insumos" },
    { id: "empaques", nombre: "Empaques y material de presentaci\xF3n" },
    { id: "repuestos", nombre: "Repuestos y accesorios" },
    { id: "importada", nombre: "Mercanc\xEDa importada" }
  ],
  "cat-servicios": [
    { id: "energia", nombre: "Energ\xEDa el\xE9ctrica" },
    { id: "acueducto", nombre: "Acueducto y alcantarillado" },
    { id: "gas", nombre: "Gas natural" },
    { id: "internet", nombre: "Internet y telefon\xEDa" },
    { id: "residuos", nombre: "Recolecci\xF3n de residuos especiales" },
    { id: "aseo", nombre: "Aseo (recolecci\xF3n de basuras)" }
  ],
  "cat-arriendo": [
    { id: "local", nombre: "Local comercial / sede" },
    { id: "bodega", nombre: "Bodega" },
    { id: "oficina", nombre: "Oficina" },
    { id: "parqueadero", nombre: "Parqueadero" },
    { id: "administracion", nombre: "Cuota de administraci\xF3n" }
  ],
  "cat-personal": [
    { id: "salarios", nombre: "Salarios" },
    { id: "honorarios", nombre: "Honorarios" },
    { id: "prestaciones", nombre: "Prestaciones sociales" },
    { id: "seguridad_social", nombre: "Seguridad social y parafiscales" },
    { id: "dotacion", nombre: "Dotaci\xF3n" }
  ],
  "cat-varios": [
    { id: "aseo_cafeteria", nombre: "Aseo y cafeter\xEDa" },
    { id: "papeleria", nombre: "Papeler\xEDa" },
    { id: "mantenimiento", nombre: "Mantenimiento y reparaciones" },
    { id: "publicidad", nombre: "Publicidad" },
    { id: "transporte", nombre: "Transporte y domicilios" },
    { id: "impuestos", nombre: "Impuestos, tasas y licencias" },
    { id: "bancarios", nombre: "Gastos bancarios" },
    { id: "otros", nombre: "Otros" }
  ]
};
var CATEGORIAS_DEFECTO = [
  {
    id: "cat-mercancia",
    nombre: "Compra de mercanc\xEDa",
    descripcion: "Mercanc\xEDa, insumos, materias primas y productos para reventa",
    color: "#0d9488",
    // teal-600
    icono: "ShoppingBag",
    esGasto: false,
    activo: true,
    subcategorias: SUBCATEGORIAS_COMPRA_DEFECTO["cat-mercancia"]
  },
  {
    id: "cat-servicios",
    nombre: "Gasto servicios p\xFAblicos",
    descripcion: "Energ\xEDa el\xE9ctrica, acueducto, gas, aseo, internet y telefon\xEDa",
    color: "#0284c7",
    // sky-600
    icono: "Zap",
    esGasto: true,
    activo: true,
    subcategorias: SUBCATEGORIAS_COMPRA_DEFECTO["cat-servicios"]
  },
  {
    id: "cat-arriendo",
    nombre: "Gastos arrendamientos",
    descripcion: "Canon de arriendo de locales, bodegas u oficinas",
    color: "#f97316",
    // orange-500
    icono: "Building2",
    esGasto: true,
    activo: true,
    subcategorias: SUBCATEGORIAS_COMPRA_DEFECTO["cat-arriendo"]
  },
  {
    id: "cat-personal",
    nombre: "Gastos de personal",
    descripcion: "Salarios, prestaciones, seguridad social y honorarios",
    color: "#8b5cf6",
    // violet-500
    icono: "Users",
    esGasto: true,
    activo: true,
    subcategorias: SUBCATEGORIAS_COMPRA_DEFECTO["cat-personal"]
  },
  {
    id: "cat-varios",
    nombre: "Gastos varios",
    descripcion: "Aseo, cafeter\xEDa, papeler\xEDa, mantenimiento y otros gastos operativos",
    color: "#64748b",
    // slate-500
    icono: "MoreHorizontal",
    esGasto: true,
    activo: true,
    subcategorias: SUBCATEGORIAS_COMPRA_DEFECTO["cat-varios"]
  }
];
var CENTROS_COSTO_DEFECTO = [
  {
    id: "cc-clinica",
    nombre: "Operaci\xF3n principal",
    codigo: "CC-01",
    descripcion: "Actividad principal del negocio (producci\xF3n o prestaci\xF3n de servicios)",
    color: "#0d9488",
    activo: true
  },
  {
    id: "cc-petshop",
    nombre: "Comercial / ventas",
    codigo: "CC-02",
    descripcion: "Punto de venta, mercadeo y atenci\xF3n al cliente",
    color: "#16a34a",
    activo: true
  },
  {
    id: "cc-peluqueria",
    nombre: "Log\xEDstica",
    codigo: "CC-03",
    descripcion: "Bodega, inventarios, transporte y domicilios",
    color: "#ec4899",
    activo: true
  },
  {
    id: "cc-admin",
    nombre: "Administraci\xF3n",
    codigo: "CC-04",
    descripcion: "Gerencia, contabilidad, mercadeo, pagos fijos e infraestructura general",
    color: "#6366f1",
    activo: true
  }
];
var PROVEEDORES_DEFECTO = [
  {
    id: "prov-gabrica",
    nit: "860514210",
    dv: "3",
    razonSocial: "GABRICA S.A.S.",
    nombreComercial: "Gabrica Expertos en Mascotas",
    telefono: "(601) 7458000",
    email: "contacto@gabrica.cl",
    direccion: "Autopista Medell\xEDn Km 2.5 Parque Empresarial La Florida",
    ciudad: "Bogot\xE1 D.C.",
    categoriaPredeterminadaId: "cat-concentrados",
    centroCostoPredeterminadoId: "cc-petshop",
    notas: "Distribuidor exclusivo de Hills Science Diet y NexGard",
    creadoEn: (/* @__PURE__ */ new Date()).toISOString(),
    actualizadoEn: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prov-zoetis",
    nit: "900593450",
    dv: "1",
    razonSocial: "ZOETIS COLOMBIA S.A.S.",
    nombreComercial: "Zoetis Salud Animal",
    telefono: "(601) 5941500",
    email: "pedidos.colombia@zoetis.com",
    direccion: "Cra 7 # 156-68 Edificio North Point",
    ciudad: "Bogot\xE1 D.C.",
    categoriaPredeterminadaId: "cat-medicamentos",
    centroCostoPredeterminadoId: "cc-clinica",
    notas: "Proveedor de Apoquel, Convenia, Simparica y vacunas vanguard",
    creadoEn: (/* @__PURE__ */ new Date()).toISOString(),
    actualizadoEn: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prov-msd",
    nit: "860002130",
    dv: "7",
    razonSocial: "MSD SALUD ANIMAL COLOMBIA S.A.S.",
    nombreComercial: "MSD Animal Health",
    telefono: "(601) 5925500",
    email: "atencionalcliente@merck.com",
    direccion: "Calle 100 # 19-61 Piso 10",
    ciudad: "Bogot\xE1 D.C.",
    categoriaPredeterminadaId: "cat-vacunas",
    centroCostoPredeterminadoId: "cc-clinica",
    notas: "Proveedor de Bravecto, Nobivac y Otomax",
    creadoEn: (/* @__PURE__ */ new Date()).toISOString(),
    actualizadoEn: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prov-royal",
    nit: "900223847",
    dv: "5",
    razonSocial: "ROYAL CANIN COLOMBIA S.A.S.",
    nombreComercial: "Royal Canin",
    telefono: "(601) 7443838",
    email: "pedidos@royalcanin.com.co",
    direccion: "Calle 113 # 7-21 Teleport Torre A",
    ciudad: "Bogot\xE1 D.C.",
    categoriaPredeterminadaId: "cat-concentrados",
    centroCostoPredeterminadoId: "cc-petshop",
    notas: "Dietas veterinarias Gastrointestinal, Renal, Hypoallergenic",
    creadoEn: (/* @__PURE__ */ new Date()).toISOString(),
    actualizadoEn: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prov-quirurgicos",
    nit: "900889123",
    dv: "4",
    razonSocial: "DISTRIBUIDORA MEDICO QUIRURGICA VET S.A.S.",
    nombreComercial: "VetQuir\xFArgicos",
    telefono: "(604) 4441234",
    email: "ventas@vetquirurgicos.com.co",
    direccion: "Cra 43A # 14-27",
    ciudad: "Medell\xEDn",
    categoriaPredeterminadaId: "cat-quirurgico",
    centroCostoPredeterminadoId: "cc-clinica",
    notas: "Cat\xE9teres, guantes, bistur\xED, campos y sueros ringer lactato",
    creadoEn: (/* @__PURE__ */ new Date()).toISOString(),
    actualizadoEn: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prov-inmobiliaria",
    nit: "800123987",
    dv: "9",
    razonSocial: "INMOBILIARIA DEL NORTE S.A.S.",
    nombreComercial: "Inmobiliaria del Norte",
    telefono: "(601) 3216540",
    email: "facturacion@inmodelnorte.com",
    direccion: "Cra 15 # 85-30",
    ciudad: "Bogot\xE1 D.C.",
    categoriaPredeterminadaId: "cat-arriendo",
    centroCostoPredeterminadoId: "cc-admin",
    notas: "Canon arrendamiento local principal",
    creadoEn: (/* @__PURE__ */ new Date()).toISOString(),
    actualizadoEn: (/* @__PURE__ */ new Date()).toISOString()
  },
  {
    id: "prov-servicios-energia",
    nit: "860000001",
    dv: "0",
    razonSocial: "ENEL COLOMBIA S.A. ESP",
    nombreComercial: "Enel Colombia",
    telefono: "(601) 5115115",
    email: "facturaenel@enel.com",
    direccion: "Cra 13A # 93-66",
    ciudad: "Bogot\xE1 D.C.",
    categoriaPredeterminadaId: "cat-servicios",
    centroCostoPredeterminadoId: "cc-admin",
    notas: "Servicio de energ\xEDa cl\xEDnica y hospitalizaci\xF3n 24h",
    creadoEn: (/* @__PURE__ */ new Date()).toISOString(),
    actualizadoEn: (/* @__PURE__ */ new Date()).toISOString()
  }
];

// server/basedatos.ts
var { DatabaseSync } = createRequire(import.meta.url)("node:sqlite");
var COLECCIONES = ["documentos", "ventas", "proveedores", "categorias", "centrosCosto", "observaciones", "productos", "movimientosInventario", "fichasPrecio", "empleados", "nominas", "liquidacionesIca"];
var RESPALDOS_A_CONSERVAR = 30;
var MIGRACIONES = [
  {
    version: 1,
    descripcion: "Estructura inicial: registros por colecci\xF3n, adjuntos y configuraci\xF3n",
    aplicar: (db) => {
      db.exec(`
        CREATE TABLE registros (
          coleccion      TEXT NOT NULL,
          id             TEXT NOT NULL,
          datos          TEXT NOT NULL,
          creado_en      TEXT NOT NULL,
          actualizado_en TEXT NOT NULL,
          PRIMARY KEY (coleccion, id)
        );
        CREATE TABLE adjuntos (
          documento_id  TEXT PRIMARY KEY,
          nombre        TEXT,
          tipo          TEXT,
          data_url      TEXT,
          contenido_xml TEXT
        );
        CREATE TABLE configuracion (
          clave TEXT PRIMARY KEY,
          valor TEXT NOT NULL
        );
      `);
      const ahora = (/* @__PURE__ */ new Date()).toISOString();
      const insertar = db.prepare(
        "INSERT INTO registros (coleccion, id, datos, creado_en, actualizado_en) VALUES (?, ?, ?, ?, ?)"
      );
      for (const c of CATEGORIAS_DEFECTO) insertar.run("categorias", c.id, JSON.stringify(c), ahora, ahora);
      for (const cc of CENTROS_COSTO_DEFECTO) insertar.run("centrosCosto", cc.id, JSON.stringify(cc), ahora, ahora);
      db.prepare("INSERT INTO configuracion (clave, valor) VALUES (?, ?)").run(
        "empresa",
        JSON.stringify(EMPRESA_DEFECTO)
      );
    }
  },
  {
    version: 2,
    descripcion: "Seguridad: usuarios, sesiones y bit\xE1cora de auditor\xEDa",
    aplicar: (db) => {
      db.exec(`
        CREATE TABLE usuarios (
          id             TEXT PRIMARY KEY,
          usuario        TEXT NOT NULL UNIQUE COLLATE NOCASE,
          nombre         TEXT NOT NULL,
          rol            TEXT NOT NULL CHECK (rol IN ('administrador', 'auxiliar')),
          clave_hash     TEXT NOT NULL,
          activo         INTEGER NOT NULL DEFAULT 1,
          debe_cambiar_clave INTEGER NOT NULL DEFAULT 0,
          creado_en      TEXT NOT NULL,
          ultimo_acceso  TEXT
        );
        CREATE TABLE sesiones (
          token_hash   TEXT PRIMARY KEY,
          usuario_id   TEXT NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
          creada_en    TEXT NOT NULL,
          ultimo_uso   TEXT NOT NULL,
          ip           TEXT
        );
        CREATE TABLE auditoria (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          fecha       TEXT NOT NULL,
          usuario     TEXT NOT NULL,
          accion      TEXT NOT NULL,
          coleccion   TEXT,
          registro_id TEXT,
          detalle     TEXT,
          ip          TEXT
        );
        CREATE INDEX auditoria_fecha ON auditoria (fecha);
      `);
    }
  },
  {
    version: 3,
    descripcion: "Compras: total = valor de la factura; saldo por pagar = total \u2212 retenciones \u2212 abonos",
    aplicar: (db) => {
      const filas = db.prepare("SELECT id, datos FROM registros WHERE coleccion = 'documentos'").all();
      const actualizar = db.prepare("UPDATE registros SET datos = ? WHERE coleccion = 'documentos' AND id = ?");
      for (const fila of filas) {
        const d = JSON.parse(fila.datos);
        const signo = d.tipoDocumento === "nota_credito" ? -1 : 1;
        const abs = (v) => Math.abs(Number(v) || 0);
        const ret = abs(d.totalRetenciones);
        const valorFactura = abs(d.subtotal) - abs(d.descuentos) + abs(d.totalIva) + abs(d.impoconsumo);
        let cambio = false;
        if (ret > 0 && Math.abs(abs(d.total) - (valorFactura - ret)) <= 2) {
          d.total = Math.round(valorFactura) * signo;
          cambio = true;
        }
        if (signo > 0 && Number(d.saldoPendiente) > 0) {
          const abonado = (d.pagos || []).reduce((s, p) => s + (Number(p.monto) || 0), 0);
          const saldo = Math.max(0, Math.round(abs(d.total) - ret - abonado));
          if (saldo !== d.saldoPendiente) {
            d.saldoPendiente = saldo;
            d.estadoPago = saldo === 0 ? "pagada" : abonado > 0 ? "parcial" : "pendiente";
            cambio = true;
          }
        }
        if (cambio) actualizar.run(JSON.stringify(d), fila.id);
      }
    }
  },
  {
    version: 4,
    descripcion: 'Empresa: reemplaza los datos de ejemplo por "Mi Empresa" (pantalla de inicio)',
    aplicar: (db) => {
      const fila = db.prepare("SELECT valor FROM configuracion WHERE clave = 'empresa'").get();
      if (!fila) return;
      const empresa = JSON.parse(fila.valor);
      if (empresa.razonSocial !== EMPRESA_DEFECTO.razonSocial || empresa.nit !== EMPRESA_DEFECTO.nit) return;
      const neutra = {
        ...empresa,
        razonSocial: "Mi Empresa",
        nombreComercial: "Mi Empresa",
        nit: "",
        dv: "",
        direccion: "",
        ciudad: "",
        departamento: "",
        telefono: "",
        email: "",
        whatsapp: "",
        sitioWeb: "",
        slogan: "",
        logoUrl: "",
        matriculaMercantil: "",
        regimenTributario: "",
        resolucionLegal: ""
      };
      db.prepare("UPDATE configuracion SET valor = ? WHERE clave = 'empresa'").run(JSON.stringify(neutra));
    }
  },
  {
    version: 5,
    // Hasta la 2.14 ponía la marca de un cliente. Desde Sistema de Control 2.0 el programa es genérico
    // y la marca la configura cada empresa; el número se conserva para no alterar el orden.
    descripcion: "Reservada (marca gen\xE9rica: cada empresa configura nombre, logo y color)",
    aplicar: () => void 0
  },
  {
    version: 6,
    descripcion: "Compras y gastos: subcategor\xEDas de f\xE1brica en las categor\xEDas que a\xFAn no tienen",
    aplicar: (db) => {
      const porCategoria = {
        "cat-mercancia": [["mercancia_general", "Mercanc\xEDa general para reventa"], ["materias_primas", "Materias primas e insumos"], ["empaques", "Empaques y material de presentaci\xF3n"], ["repuestos", "Repuestos y accesorios"], ["importada", "Mercanc\xEDa importada"]],
        "cat-servicios": [["energia", "Energ\xEDa el\xE9ctrica"], ["acueducto", "Acueducto y alcantarillado"], ["gas", "Gas natural"], ["internet", "Internet y telefon\xEDa"], ["residuos", "Recolecci\xF3n de residuos especiales"], ["aseo", "Aseo (recolecci\xF3n de basuras)"]],
        "cat-arriendo": [["local", "Local comercial / sede"], ["bodega", "Bodega"], ["oficina", "Oficina"], ["parqueadero", "Parqueadero"], ["administracion", "Cuota de administraci\xF3n"]],
        "cat-personal": [["salarios", "Salarios"], ["honorarios", "Honorarios"], ["prestaciones", "Prestaciones sociales"], ["seguridad_social", "Seguridad social y parafiscales"], ["dotacion", "Dotaci\xF3n"]],
        "cat-varios": [["aseo_cafeteria", "Aseo y cafeter\xEDa"], ["papeleria", "Papeler\xEDa"], ["mantenimiento", "Mantenimiento y reparaciones"], ["publicidad", "Publicidad"], ["transporte", "Transporte y domicilios"], ["impuestos", "Impuestos, tasas y licencias"], ["bancarios", "Gastos bancarios"], ["otros", "Otros"]]
      };
      const filas = db.prepare("SELECT id, datos FROM registros WHERE coleccion = 'categorias'").all();
      const actualizar = db.prepare("UPDATE registros SET datos = ? WHERE coleccion = 'categorias' AND id = ?");
      for (const fila of filas) {
        const c = JSON.parse(fila.datos);
        if (Array.isArray(c.subcategorias) || !porCategoria[c.id]) continue;
        c.subcategorias = porCategoria[c.id].map(([id, nombre]) => ({ id, nombre }));
        actualizar.run(JSON.stringify(c), fila.id);
      }
    }
  },
  {
    version: 7,
    descripcion: "Producto gen\xE9rico: categor\xEDas de venta neutras en instalaciones nuevas y nombre del dato adicional de la venta",
    aplicar: (db) => {
      const fila = db.prepare("SELECT valor FROM configuracion WHERE clave = 'empresa'").get();
      if (!fila) return;
      const empresa = JSON.parse(fila.valor);
      const ventas = db.prepare("SELECT COUNT(*) AS n FROM registros WHERE coleccion = 'ventas'").get().n;
      if (ventas > 0) {
        if (!empresa.etiquetaReferencia) empresa.etiquetaReferencia = "Mascota";
      } else {
        if (!Array.isArray(empresa.categoriasVenta) || !empresa.categoriasVenta.length) {
          empresa.categoriasVenta = [
            { id: "productos", label: "Productos", tipo: "producto", activo: true, subcategorias: [{ value: "general", label: "L\xEDnea general" }, { value: "varios", label: "Varios" }] },
            { id: "servicios", label: "Servicios", tipo: "servicio", activo: true, subcategorias: [{ value: "general", label: "Servicio general" }, { value: "varios", label: "Varios" }] },
            { id: "otros_ingresos", label: "Otros ingresos", tipo: "servicio", activo: true, subcategorias: [{ value: "varios", label: "Varios" }] }
          ];
        }
        if (!empresa.etiquetaReferencia) empresa.etiquetaReferencia = "Referencia";
      }
      db.prepare("UPDATE configuracion SET valor = ? WHERE clave = 'empresa'").run(JSON.stringify(empresa));
    }
  }
];
var VERSION_ESQUEMA = MIGRACIONES[MIGRACIONES.length - 1].version;
function carpetaDatosPorDefecto() {
  const configurada = process.env.SISTEMA_CONTROL_DATOS || process.env.VETCOMPRAS_DATOS;
  if (configurada) return configurada;
  const anterior = path.join(os.homedir(), "VetCompras", "datos");
  if (fs.existsSync(path.join(anterior, "vetcompras.db"))) return anterior;
  return path.join(os.homedir(), "SistemaControl", "datos");
}
function marcaDeTiempo() {
  return (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-").slice(0, 19);
}
var BaseDatosLocal = class {
  constructor(carpetaDatos = carpetaDatosPorDefecto()) {
    /** Contador que cambia con cada escritura; los navegadores lo consultan para refrescarse. */
    this.revision = 0;
    this.inicioServidor = Date.now().toString(36);
    this.ultimoRespaldoExterno = null;
    this.carpetaDatos = carpetaDatos;
    this.carpetaRespaldos = path.join(carpetaDatos, "respaldos");
    this.rutaArchivo = path.join(carpetaDatos, "vetcompras.db");
    fs.mkdirSync(this.carpetaRespaldos, { recursive: true });
    const existia = fs.existsSync(this.rutaArchivo);
    this.abrir(existia);
    if (existia) this.respaldoDiario();
  }
  abrir(existia) {
    this.db = new DatabaseSync(this.rutaArchivo);
    this.db.exec("PRAGMA journal_mode = WAL; PRAGMA synchronous = FULL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;");
    this.migrar(existia);
  }
  // ---------------------------------------------------------------- versión
  versionEsquema() {
    const fila = this.db.prepare("PRAGMA user_version").get();
    return fila.user_version;
  }
  migrar(existia) {
    const actual = this.versionEsquema();
    if (actual > VERSION_ESQUEMA) {
      throw new Error(
        `La base de datos (versi\xF3n ${actual}) es m\xE1s nueva que este programa (versi\xF3n ${VERSION_ESQUEMA}). Instale la versi\xF3n m\xE1s reciente de Sistema de Control; no se modific\xF3 ning\xFAn dato.`
      );
    }
    const pendientes = MIGRACIONES.filter((m) => m.version > actual);
    if (pendientes.length === 0) return;
    if (existia && actual > 0) {
      this.crearRespaldo(`antes-de-actualizar-v${actual}-a-v${VERSION_ESQUEMA}`);
    }
    for (const m of pendientes) {
      this.transaccion(() => {
        m.aplicar(this.db);
        this.db.exec(`PRAGMA user_version = ${m.version}`);
      });
      console.log(`[Sistema de Control] Migraci\xF3n ${m.version} aplicada: ${m.descripcion}`);
    }
  }
  transaccion(fn) {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const resultado = fn();
      this.db.exec("COMMIT");
      return resultado;
    } catch (err) {
      this.db.exec("ROLLBACK");
      throw err;
    }
  }
  // -------------------------------------------------------------- respaldos
  /** Copia consistente de la base de datos (VACUUM INTO). Devuelve la ruta creada. */
  crearRespaldo(motivo = "manual") {
    const base = `vetcompras-${marcaDeTiempo()}-${motivo.replace(/[^a-z0-9-]/gi, "_")}`;
    let destino = path.join(this.carpetaRespaldos, `${base}.db`);
    for (let n = 2; fs.existsSync(destino); n++) destino = path.join(this.carpetaRespaldos, `${base}-${n}.db`);
    this.db.prepare("VACUUM INTO ?").run(destino);
    this.depurarRespaldos();
    this.copiarARespaldoExterno(destino);
    return destino;
  }
  /** Crea el respaldo del día si aún no existe. El servidor lo llama al iniciar y cada hora. */
  respaldoDiario() {
    const hoy = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    const yaExiste = this.listarRespaldos().some((r) => r.nombre.includes(hoy) && r.nombre.includes("diario"));
    if (!yaExiste) this.crearRespaldo("diario");
  }
  rutaRespaldo(nombre) {
    if (!/^vetcompras-[\w-]+\.db$/.test(nombre)) throw Object.assign(new Error("Nombre de respaldo no v\xE1lido."), { status: 400 });
    const ruta = path.join(this.carpetaRespaldos, nombre);
    if (!fs.existsSync(ruta)) throw Object.assign(new Error("El respaldo no existe."), { status: 404 });
    return ruta;
  }
  /**
   * Reemplaza la base de datos actual por un respaldo. Antes guarda un respaldo
   * del estado actual, de modo que la restauración también se puede deshacer.
   */
  restaurarRespaldo(nombre) {
    const origen = this.rutaRespaldo(nombre);
    const prueba = new DatabaseSync(origen, { readOnly: true });
    try {
      const { user_version } = prueba.prepare("PRAGMA user_version").get();
      const tabla = prueba.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'registros'").get();
      if (!tabla) throw new Error("El archivo no es un respaldo de Sistema de Control.");
      if (user_version > VERSION_ESQUEMA) throw new Error("El respaldo es de una versi\xF3n m\xE1s nueva del programa.");
    } finally {
      prueba.close();
    }
    const previo = this.crearRespaldo("antes-de-restaurar");
    this.db.close();
    for (const sufijo of ["-wal", "-shm"]) fs.rmSync(this.rutaArchivo + sufijo, { force: true });
    fs.copyFileSync(origen, this.rutaArchivo);
    this.abrir(true);
    this.tocar();
    return previo;
  }
  // ------------------------------------------------- recordatorio de copias
  /**
   * Una "copia de seguridad" para el recordatorio es la que hace el usuario
   * (manual, descargada o copiada a otra carpeta). Los respaldos automáticos
   * diarios quedan en el mismo disco y no protegen ante daño o robo del PC.
   */
  registrarCopiaSeguridad(medio) {
    this.guardarConfig("ultimaCopiaSeguridad", { fecha: (/* @__PURE__ */ new Date()).toISOString(), medio });
  }
  estadoCopias() {
    const ultima = this.obtenerConfig("ultimaCopiaSeguridad") || null;
    const diasRecordatorio = this.obtenerConfig("politicaRespaldo")?.diasRecordatorio || 7;
    const diasSinCopia = ultima ? Math.floor((Date.now() - new Date(ultima.fecha).getTime()) / 864e5) : null;
    return { ultima, diasSinCopia, diasRecordatorio };
  }
  configurarRecordatorio(dias) {
    if (!Number.isInteger(dias) || dias < 1 || dias > 90) {
      throw Object.assign(new Error("El recordatorio debe estar entre 1 y 90 d\xEDas."), { status: 400 });
    }
    this.guardarConfig("politicaRespaldo", { diasRecordatorio: dias });
  }
  /**
   * Guarda en la carpeta de respaldos un archivo .db traído de otro lugar
   * (USB, correo, otro PC) después de comprobar que es una copia válida de VetCompras.
   * Luego se restaura desde la lista como cualquier otro respaldo.
   */
  cargarRespaldo(contenido) {
    if (contenido.length < 100 || contenido.subarray(0, 16).toString("latin1") !== "SQLite format 3\0") {
      throw Object.assign(new Error("El archivo no es una copia de seguridad de Sistema de Control (.db)."), { status: 400 });
    }
    const nombre = `vetcompras-${marcaDeTiempo()}-cargado.db`;
    const destino = path.join(this.carpetaRespaldos, nombre);
    fs.writeFileSync(destino, contenido);
    try {
      const prueba = new DatabaseSync(destino, { readOnly: true });
      try {
        const tabla = prueba.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'registros'").get();
        const { user_version } = prueba.prepare("PRAGMA user_version").get();
        if (!tabla) throw new Error("El archivo no contiene datos de Sistema de Control.");
        if (user_version > VERSION_ESQUEMA) throw new Error("La copia es de una versi\xF3n m\xE1s nueva del programa. Actualice Sistema de Control primero.");
      } finally {
        prueba.close();
      }
    } catch (err) {
      fs.rmSync(destino, { force: true });
      throw Object.assign(new Error(err?.message || "El archivo est\xE1 da\xF1ado o no es una copia v\xE1lida."), { status: 400 });
    }
    return nombre;
  }
  // ------------------------------------------------------- respaldo externo
  /** Segunda carpeta (otro disco, USB u OneDrive) donde se copia cada respaldo. */
  carpetaRespaldoExterno() {
    return this.obtenerConfig("respaldoExterno")?.carpeta || void 0;
  }
  configurarRespaldoExterno(carpeta) {
    if (carpeta) {
      if (!path.isAbsolute(carpeta)) throw Object.assign(new Error("Escriba la ruta completa de la carpeta (ej. D:\\Respaldos)."), { status: 400 });
      try {
        fs.mkdirSync(carpeta, { recursive: true });
        const prueba = path.join(carpeta, ".vetcompras-prueba");
        fs.writeFileSync(prueba, "ok");
        fs.rmSync(prueba);
      } catch {
        throw Object.assign(new Error("No se puede escribir en esa carpeta. Verifique que la USB o el disco est\xE9n conectados."), { status: 400 });
      }
    }
    this.guardarConfig("respaldoExterno", { carpeta: carpeta || "" });
  }
  copiarARespaldoExterno(archivo) {
    const carpeta = this.carpetaRespaldoExterno();
    if (!carpeta) return;
    const fecha = (/* @__PURE__ */ new Date()).toISOString();
    try {
      fs.mkdirSync(carpeta, { recursive: true });
      fs.copyFileSync(archivo, path.join(carpeta, path.basename(archivo)));
      const rotativos = fs.readdirSync(carpeta).filter((f) => /^vetcompras-.*\.db$/.test(f) && !f.includes("antes-de-actualizar")).sort().reverse();
      for (const f of rotativos.slice(RESPALDOS_A_CONSERVAR)) fs.rmSync(path.join(carpeta, f), { force: true });
      this.ultimoRespaldoExterno = { fecha, ok: true, mensaje: `Copiado a ${carpeta}` };
      this.registrarCopiaSeguridad("copia autom\xE1tica en carpeta externa");
    } catch (err) {
      this.ultimoRespaldoExterno = { fecha, ok: false, mensaje: `No se pudo copiar a ${carpeta}: ${err?.message}` };
      console.warn("[Sistema de Control]", this.ultimoRespaldoExterno.mensaje);
    }
  }
  listarRespaldos() {
    return fs.readdirSync(this.carpetaRespaldos).filter((f) => f.endsWith(".db")).map((nombre) => {
      const st = fs.statSync(path.join(this.carpetaRespaldos, nombre));
      return { nombre, tamano: st.size, fecha: st.mtime.toISOString() };
    }).sort((a, b) => b.fecha.localeCompare(a.fecha));
  }
  depurarRespaldos() {
    const rotativos = this.listarRespaldos().filter((r) => !r.nombre.includes("antes-de-actualizar"));
    for (const r of rotativos.slice(RESPALDOS_A_CONSERVAR)) {
      fs.rmSync(path.join(this.carpetaRespaldos, r.nombre), { force: true });
    }
  }
  // --------------------------------------------------------------- revisión
  obtenerRevision() {
    return `${this.inicioServidor}-${this.revision}`;
  }
  tocar() {
    this.revision++;
  }
  // -------------------------------------------------------------- registros
  listar(coleccion) {
    const filas = this.db.prepare("SELECT datos FROM registros WHERE coleccion = ?").all(coleccion);
    return filas.map((f) => JSON.parse(f.datos));
  }
  obtener(coleccion, id) {
    const fila = this.db.prepare("SELECT datos FROM registros WHERE coleccion = ? AND id = ?").get(coleccion, id);
    if (!fila) return void 0;
    const registro = JSON.parse(fila.datos);
    if (coleccion === "documentos") this.adjuntarContenido(registro);
    return registro;
  }
  existe(coleccion, id) {
    return !!this.db.prepare("SELECT 1 AS si FROM registros WHERE coleccion = ? AND id = ?").get(coleccion, id);
  }
  guardar(coleccion, registro) {
    this.transaccion(() => this.guardarSinTransaccion(coleccion, registro));
    this.tocar();
  }
  guardarSinTransaccion(coleccion, registro) {
    if (!registro || typeof registro.id !== "string" || !registro.id) {
      throw new Error('El registro debe tener un "id" de texto.');
    }
    const datos = coleccion === "documentos" ? this.separarAdjunto(registro) : registro;
    const ahora = (/* @__PURE__ */ new Date()).toISOString();
    this.db.prepare(
      `INSERT INTO registros (coleccion, id, datos, creado_en, actualizado_en) VALUES (?, ?, ?, ?, ?)
         ON CONFLICT (coleccion, id) DO UPDATE SET datos = excluded.datos, actualizado_en = excluded.actualizado_en`
    ).run(coleccion, registro.id, JSON.stringify(datos), ahora, ahora);
  }
  eliminar(coleccion, ids) {
    this.transaccion(() => this.eliminarSinTransaccion(coleccion, ids));
    this.tocar();
  }
  eliminarSinTransaccion(coleccion, ids) {
    const borrar = this.db.prepare("DELETE FROM registros WHERE coleccion = ? AND id = ?");
    const borrarAdjunto = this.db.prepare("DELETE FROM adjuntos WHERE documento_id = ?");
    for (const id of ids) {
      borrar.run(coleccion, id);
      if (coleccion === "documentos") borrarAdjunto.run(id);
    }
  }
  /** Guarda y elimina varios registros de forma atómica. */
  lote(coleccion, guardar = [], eliminar = []) {
    this.transaccion(() => {
      for (const r of guardar) this.guardarSinTransaccion(coleccion, r);
      this.eliminarSinTransaccion(coleccion, eliminar);
    });
    this.tocar();
  }
  vaciar(coleccion) {
    this.transaccion(() => {
      this.db.prepare("DELETE FROM registros WHERE coleccion = ?").run(coleccion);
      if (coleccion === "documentos") this.db.exec("DELETE FROM adjuntos");
    });
    this.tocar();
  }
  /**
   * Los PDF/XML anexos se guardan en la tabla `adjuntos` para que el listado
   * general cargue rápido. Si un documento llega sin contenido de adjunto
   * (por ejemplo al editarlo desde el listado), se conserva el existente.
   */
  separarAdjunto(documento) {
    const adj = documento.archivoAdjunto;
    if (!adj) {
      this.db.prepare("DELETE FROM adjuntos WHERE documento_id = ?").run(documento.id);
      return documento;
    }
    const { dataUrl, contenidoXml, ...resto } = adj;
    if (dataUrl || contenidoXml) {
      this.db.prepare(
        `INSERT INTO adjuntos (documento_id, nombre, tipo, data_url, contenido_xml) VALUES (?, ?, ?, ?, ?)
           ON CONFLICT (documento_id) DO UPDATE SET nombre = excluded.nombre, tipo = excluded.tipo,
             data_url = excluded.data_url, contenido_xml = excluded.contenido_xml`
      ).run(documento.id, adj.nombre ?? null, adj.tipo ?? null, dataUrl ?? null, contenidoXml ?? null);
    }
    const existe2 = this.db.prepare("SELECT 1 AS si FROM adjuntos WHERE documento_id = ?").get(documento.id);
    return { ...documento, archivoAdjunto: { ...resto, tieneContenido: !!existe2 } };
  }
  adjuntarContenido(documento) {
    if (!documento.archivoAdjunto) return;
    const fila = this.db.prepare("SELECT data_url, contenido_xml FROM adjuntos WHERE documento_id = ?").get(documento.id);
    if (fila?.data_url) documento.archivoAdjunto.dataUrl = fila.data_url;
    if (fila?.contenido_xml) documento.archivoAdjunto.contenidoXml = fila.contenido_xml;
  }
  // ---------------------------------------------------------- configuración
  obtenerConfig(clave) {
    const fila = this.db.prepare("SELECT valor FROM configuracion WHERE clave = ?").get(clave);
    return fila ? JSON.parse(fila.valor) : void 0;
  }
  guardarConfig(clave, valor) {
    this.db.prepare(
      "INSERT INTO configuracion (clave, valor) VALUES (?, ?) ON CONFLICT (clave) DO UPDATE SET valor = excluded.valor"
    ).run(clave, JSON.stringify(valor));
    this.tocar();
  }
  // ---------------------------------------------------- respaldo completo JSON
  exportarTodo() {
    const respaldo = {
      version: "2.0",
      aplicacion: "Sistema de Control",
      versionEsquema: this.versionEsquema(),
      fechaExportacion: (/* @__PURE__ */ new Date()).toISOString(),
      empresa: this.obtenerConfig("empresa")
    };
    for (const c of COLECCIONES) {
      respaldo[c] = c === "documentos" ? this.listar(c).map((d) => this.obtener(c, d.id)) : this.listar(c);
    }
    return respaldo;
  }
  /**
   * Importa un respaldo JSON (de esta versión o del VetCompras anterior basado
   * en navegador). Combina por id: nunca borra registros que no vengan en el archivo.
   */
  importarTodo(datos) {
    if (!datos || typeof datos !== "object") throw new Error("El respaldo no tiene un formato v\xE1lido.");
    this.crearRespaldo("antes-de-importar");
    const conteo = {};
    this.transaccion(() => {
      for (const c of COLECCIONES) {
        const lista = Array.isArray(datos[c]) ? datos[c].filter((r) => r && r.id) : [];
        for (const r of lista) this.guardarSinTransaccion(c, r);
        conteo[c] = lista.length;
      }
      if (datos.empresa && typeof datos.empresa === "object") {
        this.db.prepare(
          "INSERT INTO configuracion (clave, valor) VALUES (?, ?) ON CONFLICT (clave) DO UPDATE SET valor = excluded.valor"
        ).run("empresa", JSON.stringify(datos.empresa));
      }
    });
    this.tocar();
    return conteo;
  }
  // -------------------------------------------------------------- auditoría
  auditar(e) {
    this.db.prepare(
      "INSERT INTO auditoria (fecha, usuario, accion, coleccion, registro_id, detalle, ip) VALUES (?, ?, ?, ?, ?, ?, ?)"
    ).run((/* @__PURE__ */ new Date()).toISOString(), e.usuario, e.accion, e.coleccion ?? null, e.registroId ?? null, e.detalle ?? null, e.ip ?? null);
  }
  listarAuditoria(limite = 300, texto = "") {
    const filtro = `%${texto}%`;
    return this.db.prepare(
      `SELECT fecha, usuario, accion, coleccion, registro_id AS registroId, detalle, ip FROM auditoria
         WHERE ? = '%%' OR usuario LIKE ? OR accion LIKE ? OR detalle LIKE ? OR registro_id LIKE ?
         ORDER BY id DESC LIMIT ?`
    ).all(filtro, filtro, filtro, filtro, filtro, Math.min(Math.max(limite, 1), 2e3));
  }
  cerrar() {
    try {
      this.db.exec("PRAGMA wal_checkpoint(TRUNCATE)");
    } catch {
    }
    this.db.close();
  }
};

// server/seguridad.ts
import crypto from "node:crypto";
var MINUTOS_INACTIVIDAD = Number(process.env.MINUTOS_INACTIVIDAD) || 60;
var LONGITUD_MINIMA_CLAVE = 8;
var INTENTOS_MAXIMOS = 5;
var MINUTOS_BLOQUEO = 10;
var error = (status, mensaje) => Object.assign(new Error(mensaje), { status });
function cifrarClave(clave) {
  const sal = crypto.randomBytes(16);
  const hash = crypto.scryptSync(clave, sal, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$16384$${sal.toString("base64")}$${hash.toString("base64")}`;
}
function verificarClave(clave, guardado) {
  const [alg, n, salB64, hashB64] = guardado.split("$");
  if (alg !== "scrypt" || !salB64 || !hashB64) return false;
  const esperado = Buffer.from(hashB64, "base64");
  const calculado = crypto.scryptSync(clave, Buffer.from(salB64, "base64"), esperado.length, {
    N: Number(n),
    r: 8,
    p: 1
  });
  return crypto.timingSafeEqual(esperado, calculado);
}
function validarClave(clave) {
  if (typeof clave !== "string" || clave.length < LONGITUD_MINIMA_CLAVE) {
    throw error(400, `La contrase\xF1a debe tener al menos ${LONGITUD_MINIMA_CLAVE} caracteres.`);
  }
  if (!/[a-zA-Z]/.test(clave) || !/\d/.test(clave)) {
    throw error(400, "La contrase\xF1a debe combinar letras y n\xFAmeros.");
  }
  return clave;
}
var hashToken = (token) => crypto.createHash("sha256").update(token).digest("hex");
var aSesion = (u) => ({
  id: u.id,
  usuario: u.usuario,
  nombre: u.nombre,
  rol: u.rol,
  debeCambiarClave: !!u.debe_cambiar_clave
});
var Seguridad = class {
  constructor(bd2) {
    this.bd = bd2;
    /** Intentos fallidos por usuario + equipo (en memoria: se reinicia con el programa). */
    this.intentos = /* @__PURE__ */ new Map();
  }
  verificarBloqueo(clave) {
    const reg = this.intentos.get(clave);
    if (reg && reg.bloqueadoHasta > Date.now()) {
      const minutos = Math.ceil((reg.bloqueadoHasta - Date.now()) / 6e4);
      throw error(429, `Demasiados intentos fallidos. Espere ${minutos} minuto(s) e intente de nuevo.`);
    }
  }
  registrarFallo(clave) {
    const reg = this.intentos.get(clave) || { fallos: 0, bloqueadoHasta: 0 };
    reg.fallos++;
    if (reg.fallos >= INTENTOS_MAXIMOS) {
      reg.fallos = 0;
      reg.bloqueadoHasta = Date.now() + MINUTOS_BLOQUEO * 6e4;
    }
    this.intentos.set(clave, reg);
  }
  get db() {
    return this.bd.db;
  }
  hayUsuarios() {
    return !!this.db.prepare("SELECT 1 AS si FROM usuarios LIMIT 1").get();
  }
  listarUsuarios() {
    const filas = this.db.prepare("SELECT * FROM usuarios ORDER BY activo DESC, nombre").all();
    return filas.map((u) => ({
      ...aSesion(u),
      activo: !!u.activo,
      creadoEn: u.creado_en,
      ultimoAcceso: u.ultimo_acceso
    }));
  }
  crearUsuario(datos, debeCambiarClave = false) {
    const usuario = String(datos.usuario || "").trim().toLowerCase();
    const nombre = String(datos.nombre || "").trim();
    const rol = datos.rol === "administrador" ? "administrador" : "auxiliar";
    if (!/^[a-z0-9._-]{3,30}$/.test(usuario)) {
      throw error(400, "El usuario debe tener entre 3 y 30 letras, n\xFAmeros, punto o guion (sin espacios).");
    }
    if (!nombre) throw error(400, "Escriba el nombre de la persona.");
    const clave = validarClave(datos.clave);
    if (this.db.prepare("SELECT 1 AS si FROM usuarios WHERE usuario = ?").get(usuario)) {
      throw error(409, `Ya existe el usuario "${usuario}".`);
    }
    const id = "usr-" + crypto.randomUUID();
    this.db.prepare(
      `INSERT INTO usuarios (id, usuario, nombre, rol, clave_hash, activo, debe_cambiar_clave, creado_en)
         VALUES (?, ?, ?, ?, ?, 1, ?, ?)`
    ).run(id, usuario, nombre, rol, cifrarClave(clave), debeCambiarClave ? 1 : 0, (/* @__PURE__ */ new Date()).toISOString());
    return id;
  }
  actualizarUsuario(id, cambios, quien) {
    const actual = this.db.prepare("SELECT * FROM usuarios WHERE id = ?").get(id);
    if (!actual) throw error(404, "Usuario no encontrado.");
    const rol = cambios.rol === void 0 ? actual.rol : cambios.rol === "administrador" ? "administrador" : "auxiliar";
    const activo = cambios.activo === void 0 ? !!actual.activo : !!cambios.activo;
    const nombre = cambios.nombre === void 0 ? actual.nombre : String(cambios.nombre).trim() || actual.nombre;
    if (id === quien.id && (!activo || rol !== "administrador")) {
      throw error(400, "No puede desactivarse ni quitarse el rol de administrador a s\xED mismo.");
    }
    if (actual.rol === "administrador" && actual.activo && (rol !== "administrador" || !activo)) {
      const otros = this.db.prepare("SELECT COUNT(*) AS n FROM usuarios WHERE rol = 'administrador' AND activo = 1 AND id <> ?").get(id);
      if (otros.n === 0) throw error(400, "Debe quedar al menos un administrador activo.");
    }
    this.db.prepare("UPDATE usuarios SET nombre = ?, rol = ?, activo = ? WHERE id = ?").run(nombre, rol, activo ? 1 : 0, id);
    if (!activo) this.db.prepare("DELETE FROM sesiones WHERE usuario_id = ?").run(id);
  }
  /** Un administrador asigna una contraseña temporal; el usuario deberá cambiarla al entrar. */
  restablecerClave(id, claveTemporal) {
    const clave = validarClave(claveTemporal);
    const r = this.db.prepare("UPDATE usuarios SET clave_hash = ?, debe_cambiar_clave = 1 WHERE id = ?").run(cifrarClave(clave), id);
    if (r.changes === 0) throw error(404, "Usuario no encontrado.");
    this.db.prepare("DELETE FROM sesiones WHERE usuario_id = ?").run(id);
  }
  cambiarClavePropia(usuario, claveActual, claveNueva, tokenActual) {
    const fila = this.db.prepare("SELECT * FROM usuarios WHERE id = ?").get(usuario.id);
    if (!fila || !verificarClave(String(claveActual || ""), fila.clave_hash)) {
      throw error(400, "La contrase\xF1a actual no es correcta.");
    }
    const nueva = validarClave(claveNueva);
    if (nueva === claveActual) throw error(400, "La nueva contrase\xF1a debe ser diferente a la actual.");
    this.db.prepare("UPDATE usuarios SET clave_hash = ?, debe_cambiar_clave = 0 WHERE id = ?").run(cifrarClave(nueva), usuario.id);
    this.db.prepare("DELETE FROM sesiones WHERE usuario_id = ? AND token_hash <> ?").run(usuario.id, hashToken(tokenActual));
  }
  iniciarSesion(usuarioTexto, clave, ip) {
    const usuario = String(usuarioTexto || "").trim().toLowerCase();
    const claveBloqueo = `${usuario}|${ip}`;
    this.verificarBloqueo(claveBloqueo);
    const fila = this.db.prepare("SELECT * FROM usuarios WHERE usuario = ?").get(usuario);
    const valido = verificarClave(String(clave || ""), fila?.clave_hash || FALSO_HASH) && !!fila;
    if (!valido || !fila) {
      this.registrarFallo(claveBloqueo);
      this.bd.auditar({ usuario: usuario || "(vac\xEDo)", accion: "Intento de ingreso fallido", ip });
      throw error(401, "Usuario o contrase\xF1a incorrectos.");
    }
    if (!fila.activo) {
      this.bd.auditar({ usuario, accion: "Ingreso rechazado (usuario inactivo)", ip });
      throw error(403, "Este usuario est\xE1 desactivado. Consulte al administrador.");
    }
    this.intentos.delete(claveBloqueo);
    this.bd.auditar({ usuario, accion: "Inicio de sesi\xF3n", ip });
    return this.crearSesion(fila, ip);
  }
  crearSesion(fila, ip) {
    const token = crypto.randomBytes(32).toString("base64url");
    const ahora = (/* @__PURE__ */ new Date()).toISOString();
    this.purgarSesionesVencidas();
    this.db.prepare("INSERT INTO sesiones (token_hash, usuario_id, creada_en, ultimo_uso, ip) VALUES (?, ?, ?, ?, ?)").run(hashToken(token), fila.id, ahora, ahora, ip);
    this.db.prepare("UPDATE usuarios SET ultimo_acceso = ? WHERE id = ?").run(ahora, fila.id);
    return { token, usuario: aSesion(fila) };
  }
  // ------------------------------------------------------------ modo de acceso
  /**
   * 'libre' (por defecto): pantalla de inicio con botón "Ingresar", sin usuario ni
   * contraseña; todo queda a nombre de la empresa (administrador).
   * 'usuarios': cada persona ingresa con usuario y contraseña, con roles.
   */
  modoAcceso() {
    return this.bd.obtenerConfig("modoAcceso")?.modo === "usuarios" ? "usuarios" : "libre";
  }
  /** Ingreso con el botón de la pantalla de inicio (solo en modo libre). */
  ingresarSinClave(ip) {
    if (this.modoAcceso() !== "libre") {
      throw error(403, "Este equipo pide usuario y contrase\xF1a para ingresar.");
    }
    let fila = this.db.prepare("SELECT * FROM usuarios WHERE rol = 'administrador' AND activo = 1 ORDER BY creado_en LIMIT 1").get();
    if (!fila) {
      const clave = "A1" + crypto.randomBytes(18).toString("base64url");
      const id = this.crearUsuario({ usuario: "empresa", nombre: "Empresa", rol: "administrador", clave });
      fila = this.db.prepare("SELECT * FROM usuarios WHERE id = ?").get(id);
    }
    this.db.prepare("UPDATE usuarios SET debe_cambiar_clave = 0 WHERE id = ?").run(fila.id);
    fila.debe_cambiar_clave = 0;
    this.bd.auditar({ usuario: fila.usuario, accion: "Ingreso (pantalla de inicio, sin contrase\xF1a)", ip });
    return this.crearSesion(fila, ip);
  }
  /**
   * Activa el ingreso con usuario y contraseña. La persona que lo activa queda
   * como administrador con las credenciales que escribe, para no quedar por fuera.
   */
  activarUsuarios(quien, usuarioTexto, claveTexto) {
    const usuario = String(usuarioTexto || "").trim().toLowerCase();
    if (!/^[a-z0-9._-]{3,30}$/.test(usuario)) {
      throw error(400, "El usuario debe tener entre 3 y 30 letras, n\xFAmeros, punto o guion (sin espacios).");
    }
    const clave = validarClave(claveTexto);
    const otro = this.db.prepare("SELECT id FROM usuarios WHERE usuario = ? AND id <> ?").get(usuario, quien.id);
    if (otro) throw error(409, `Ya existe el usuario "${usuario}".`);
    this.db.prepare("UPDATE usuarios SET usuario = ?, clave_hash = ?, debe_cambiar_clave = 0 WHERE id = ?").run(usuario, cifrarClave(clave), quien.id);
    this.bd.guardarConfig("modoAcceso", { modo: "usuarios" });
  }
  activarAccesoLibre() {
    this.bd.guardarConfig("modoAcceso", { modo: "libre" });
  }
  cerrarSesion(token) {
    this.db.prepare("DELETE FROM sesiones WHERE token_hash = ?").run(hashToken(token));
  }
  /**
   * Devuelve el usuario de la sesión si sigue vigente. `renovar` = false para
   * las consultas automáticas de la pantalla, que no deben mantener viva una
   * sesión que nadie está usando.
   */
  validarSesion(token, renovar) {
    if (!token) return null;
    const fila = this.db.prepare(
      `SELECT u.*, s.ultimo_uso FROM sesiones s JOIN usuarios u ON u.id = s.usuario_id
         WHERE s.token_hash = ? AND u.activo = 1`
    ).get(hashToken(token));
    if (!fila) return null;
    if (Date.now() - new Date(fila.ultimo_uso).getTime() > MINUTOS_INACTIVIDAD * 6e4) {
      this.cerrarSesion(token);
      return null;
    }
    if (renovar) {
      this.db.prepare("UPDATE sesiones SET ultimo_uso = ? WHERE token_hash = ?").run((/* @__PURE__ */ new Date()).toISOString(), hashToken(token));
    }
    return aSesion(fila);
  }
  purgarSesionesVencidas() {
    const limite = new Date(Date.now() - MINUTOS_INACTIVIDAD * 6e4).toISOString();
    this.db.prepare("DELETE FROM sesiones WHERE ultimo_uso < ?").run(limite);
  }
};
var FALSO_HASH = cifrarClave(crypto.randomBytes(16).toString("hex"));

// scripts/recuperarAcceso.ts
var raiz = path2.join(path2.dirname(fileURLToPath(import.meta.url)), "..");
import_dotenv.default.config({ path: path2.join(raiz, ".env"), quiet: true });
var bd = new BaseDatosLocal();
var seg = new Seguridad(bd);
var letras = "ABCDEFGHJKLMNPQRSTUVWXYZ";
var temporal = Array.from({ length: 4 }, () => letras[crypto2.randomInt(letras.length)]).join("") + String(crypto2.randomInt(1e3, 1e4));
var existe = bd.db.prepare("SELECT id FROM usuarios WHERE usuario = 'recuperacion'").get();
if (existe) {
  bd.db.prepare("UPDATE usuarios SET clave_hash = ?, rol = 'administrador', activo = 1, debe_cambiar_clave = 1 WHERE id = ?").run(cifrarClave(temporal), existe.id);
} else {
  seg.crearUsuario({ usuario: "recuperacion", nombre: "Recuperaci\xF3n de acceso", rol: "administrador", clave: temporal }, true);
}
bd.auditar({ usuario: "recuperacion", accion: "Acceso de emergencia generado desde el PC servidor" });
var perfiles = bd.obtenerConfig("perfilesAcceso");
var pinQuitado = false;
if (perfiles?.perfiles?.some((p) => p.id === "administracion" && p.pin)) {
  perfiles.perfiles = perfiles.perfiles.map((p) => p.id === "administracion" ? { ...p, pin: void 0 } : p);
  bd.guardarConfig("perfilesAcceso", perfiles);
  bd.auditar({ usuario: "recuperacion", accion: "PIN del perfil Administraci\xF3n quitado desde el PC servidor" });
  pinQuitado = true;
}
bd.cerrar();
console.log("\n============================================================");
console.log("  ACCESO DE EMERGENCIA DE SISTEMA DE CONTROL");
console.log("  Usuario:              recuperacion");
console.log(`  Contrase\xF1a temporal:  ${temporal}`);
console.log("  Al ingresar se le pedir\xE1 crear una contrase\xF1a nueva.");
console.log('  Luego, en "Seguridad y Respaldos" restablezca la contrase\xF1a');
console.log('  del administrador habitual y desactive "recuperacion".');
if (pinQuitado) console.log("  Se quit\xF3 el PIN del perfil Administraci\xF3n: p\xF3ngale uno nuevo en Perfiles y Bit\xE1cora.");
console.log("============================================================\n");
