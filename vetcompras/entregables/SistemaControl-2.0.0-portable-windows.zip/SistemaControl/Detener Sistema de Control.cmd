@echo off
taskkill /fi "WINDOWTITLE eq Sistema de Control - servidor*" /t /f >nul 2>nul
echo Sistema de Control quedo cerrado.
timeout /t 3 >nul
