@echo off
chcp 65001 >nul
title Instalar Sistema de Control 2.0 en este PC
set ORIGEN=%~dp0
set DESTINO=%LOCALAPPDATA%\SistemaControl\programa

echo ============================================================
echo   INSTALAR SISTEMA DE CONTROL 2.0 EN ESTE PC
echo   Programa: %DESTINO%
if exist "%ORIGEN%ETAPA_PRUEBA" (
  echo   VERSION DE PRUEBA - datos de ensayo en: %USERPROFILE%\SistemaControl\datos-prueba
) else (
  echo   Datos:    %USERPROFILE%\SistemaControl\datos
echo   Al abrirlo por primera vez se pide la LICENCIA de este equipo.
)
echo   Si ya estaba instalado, se actualiza y los datos se conservan.
echo ============================================================
pause

rem Detener el programa si está abierto (para poder reemplazar archivos)
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }" >nul 2>nul

if exist "%DESTINO%\ETAPA_PRUEBA" del /q "%DESTINO%\ETAPA_PRUEBA"
robocopy "%ORIGEN%." "%DESTINO%" /E /NFL /NDL /NJH /NJS /XD datos datos-prueba /XF registro.log "Usar desde la USB.bat" >nul

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Sistema de Control.lnk');" ^
  "$s.TargetPath='wscript.exe';$s.Arguments='\"%DESTINO%\SistemaControl.vbs\"';$s.WorkingDirectory='%DESTINO%';$s.IconLocation='shell32.dll,43';$s.Save()"

set /p AUTO="Desea que Sistema de Control arranque solo al encender el PC? (S/N): "
if /i "%AUTO%"=="S" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\Sistema de Control.lnk');" ^
    "$s.TargetPath='wscript.exe';$s.Arguments='\"%DESTINO%\SistemaControl.vbs\" /sinNavegador';$s.WorkingDirectory='%DESTINO%';$s.Save()"
)

if exist "%ORIGEN%datos\vetcompras.db" (
  echo.
  echo Esta USB tiene datos propios en la carpeta "datos".
  echo Para pasarlos a este PC: abra Sistema de Control en la USB, Datos y Respaldo,
  echo "Exportar respaldo completo", y luego importelo en la version instalada.
)

echo.
echo LISTO. Abra Sistema de Control con el icono del escritorio.
pause
