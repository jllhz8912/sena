@echo off
chcp 65001 >nul
echo Crea un acceso de emergencia de administrador y quita el PIN del perfil Administracion.
echo Si usa Sistema de Control desde la USB, escriba U; si esta instalado en este PC, escriba P.
set /p MODO="(U/P): "
if /i "%MODO%"=="U" set "SISTEMA_CONTROL_DATOS=%~dp0datos"
"%~dp0node\node.exe" "%~dp0recuperar.mjs"
pause
