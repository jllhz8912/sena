@echo off
rem Abre Sistema de Control con los datos guardados en esta misma USB (carpeta "datos").
start "" wscript.exe "%~dp0SistemaControl.vbs" /usb
