@echo off
powershell -NoProfile -Command "$c = Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue; if ($c) { $c | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force }; Write-Host 'Sistema de Control se detuvo.' } else { Write-Host 'Sistema de Control no estaba abierto.' }"
timeout /t 3 >nul
