# Sistema de Control: textos para redes sociales

Para Instagram, Facebook, WhatsApp Business y TikTok. Úselos con las imágenes de esta carpeta. Antes de publicar, cambie **[tu WhatsApp]** por su número.

## Publicación 1 · post-1-emprendedor.png
¿Eres pequeño emprendedor y todavía llevas las cuentas en un cuaderno? 📒

Con **Sistema de Control** tienes todo tu negocio en orden:
✅ Ventas con fotos de tus productos
✅ Compras tomándole foto a la factura
✅ Inventario que se actualiza solo
✅ Nómina con todo lo de ley
✅ Impuesto de industria y comercio en un clic

Funciona en tu **PC o en tu celular**, sin internet. Tus datos se quedan contigo.
👉 Pide tu demostración gratis: [tu WhatsApp]

#Emprendedores #PequeñosNegocios #Colombia #ControlDeInventario #Nómina #Tiendas #Emprendimiento

## Publicación 2 · post-2-vende.png
Vender nunca fue tan fácil 🛒
Tocas el producto (con su foto), la caja suma sola, le haces el descuento, te calcula el cambio y le mandas el recibo al cliente por WhatsApp. Todo desde tu celular.
👉 Escríbenos: [tu WhatsApp]

#Ventas #CajaRegistradora #Emprendedores #TiendaDeBarrio #Restaurantes

## Publicación 3 · post-3-sin-internet.png
¿Se fue el internet? Tu negocio sigue funcionando 💪
Sistema de Control trabaja **sin internet**, guarda todo en tu equipo y hace copia de seguridad todos los días.
👉 Te lo instalamos hoy: [tu WhatsApp]

#SinInternet #Negocios #Colombia #Emprendedor

## Publicación 4 · post-4-nomina.png
¿Te enredas pagando la quincena? 🧾
Pon el salario y listo: el sistema calcula auxilio de transporte, salud, pensión, horas extra y recargos con la ley 2026. También saca prima, cesantías, vacaciones y la liquidación final, con el **comprobante para firma**.
👉 Más información: [tu WhatsApp]

#Nómina #Colombia2026 #Empleados #Pymes #Emprendedores

## Publicación 5 · post-5-ica.png
¿Industria y comercio? Escoge la tarifa de tu municipio y listo ✅
El sistema toma tus ventas y liquida el ICA, avisos y tableros y la sobretasa bomberil.
👉 Pide tu demostración: [tu WhatsApp]

#ICA #Impuestos #Colombia #Contabilidad #Pymes

## Historias (historia-1-todo.png, historia-2-pidela.png) y reel (Video-promocional-Sistema-de-Control.mp4)
Texto corto para la historia o el reel:
> Deja el cuaderno. Controla tu negocio desde tu celular o tu PC, sin internet. Escríbenos 👉 [tu WhatsApp]

Use el sticker de enlace a WhatsApp o "Enviar mensaje".

## Mensaje de respuesta para WhatsApp Business
¡Hola! 👋 Gracias por escribirnos. **Sistema de Control** es un aplicativo para llevar tu negocio en orden desde tu PC o tu celular, sin internet: ventas con fotos, compras con foto de la factura, inventario, nómina con todo lo de ley e impuesto de industria y comercio.
¿Quieres que te mostremos cómo funciona? Te enviamos la versión de prueba para tu celular o te lo instalamos en tu computador.

## Ideas para publicar
- **Frecuencia:** 3 publicaciones por semana y 1 historia diaria durante el primer mes.
- **Orden sugerido:** 1 → 2 → 3 → 4 → 5. Luego repita con testimonios de clientes reales, con su permiso.
- **Pauta sugerida:** Instagram y Facebook, para dueños de tiendas, restaurantes, peluquerías, ferreterías y veterinarias, de 25 a 55 años, en su ciudad y alrededores.
- **Demostración:** ofrezca la versión de prueba para celular (SistemaControl-Movil-PRUEBA.apk) para que la prueben sin compromiso.
