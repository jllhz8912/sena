const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1200, height: 1200 } });
  await p.goto('file://' + __dirname + '/piezas.html'); await p.waitForTimeout(1200);
  for (const id of await p.$$eval('.pieza', (xs) => xs.map((x) => x.id))) {
    await p.locator('#' + id).screenshot({ path: __dirname + '/' + id + '.png' });
    console.log(id);
  }
  await b.close();
})();
